[Accounts]
Login pages of the customers and the administrators will be different
Customer login page - customersignin.html
Staff login page - stafflogin.php

[Customer accounts]
1. 	Username: BlueBanana
	Password: Lamborghini05

2.	Username: chloe
	Password: chloooee9696
	
3. 	Username: echo
	Password: echoindahouse
	
--------------------------------------

[Adminitrator accounts]
Manager: 				Username: ethanchongxz@spanishfly
						Password: 0000
		 
Boarding administrator: Username: lionellow@spanishfly
						Password: 1234

Flight administrator: 	Username: yeewl@spanishfly
						Password: 1234
						
Crew administrator: 	Username: syahirsalmi@spanishfly
						Password: 1234
						
Flight sales administrator: Username: thuwb@spanishfly
							Password: 1234