<script>
function myFunction(){
    alert("Sorry, there are no seat available at your selected flight.");
}

</script>